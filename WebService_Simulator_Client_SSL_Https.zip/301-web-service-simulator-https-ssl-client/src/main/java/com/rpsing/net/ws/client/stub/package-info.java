@javax.xml.bind.annotation.XmlSchema(namespace = "http://rpsoft.com/ws/greeting/beans")
package com.rpsing.net.ws.client.stub;
