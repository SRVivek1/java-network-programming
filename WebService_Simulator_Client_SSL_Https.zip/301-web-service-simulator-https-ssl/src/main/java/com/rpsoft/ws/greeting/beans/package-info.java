@javax.xml.bind.annotation.XmlSchema(namespace = "http://rpsoft.com/ws/greeting/beans")
package com.rpsoft.ws.greeting.beans;
